export class HelloWorld {
  public hello(name: string): string {
    return `Hello ${name}`;
  }
}
