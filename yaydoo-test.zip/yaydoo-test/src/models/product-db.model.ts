export interface ProductBDModel {
    category: string;
    author: string;
    id: string;
    name: string;
    coverImage: string;
    ratingValue: string;
    ratingTotal: string;
}